const API_BASE = "http://localhost:3000";

const blogForm = document.getElementById("blogForm");
const blogsContainer = document.getElementById("blogs");

// Load blogs
async function loadBlogs() {
  const res = await fetch(`${API_BASE}/blogs`);
  const blogs = await res.json();

  blogsContainer.innerHTML = "";
  blogs.forEach(blog => {
    const div = document.createElement("div");
    div.className = "blog-card";
    div.innerHTML = `
      <h3>${blog.title}</h3>
      <p><b>Category:</b> ${blog.category || "N/A"}</p>
      <p>${blog.content}</p>
      <p><b>Likes:</b> ${blog.likes}</p>
      <button onclick="likeBlog('${blog._id}', ${blog.likes})">👍 Like</button>
      <button onclick="deleteBlog('${blog._id}')">🗑 Delete</button>
    `;
    blogsContainer.appendChild(div);
  });
}

// Create blog
blogForm.addEventListener("submit", async (e) => {
  e.preventDefault();

  const newBlog = {
    title: document.getElementById("title").value,
    category: document.getElementById("category").value,
    content: document.getElementById("content").value,
    authorId: document.getElementById("authorId").value
  };

  await fetch(`${API_BASE}/blogs`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(newBlog)
  });

  blogForm.reset();
  loadBlogs();
});

// Delete blog
async function deleteBlog(id) {
  await fetch(`${API_BASE}/blogs/${id}`, { method: "DELETE" });
  loadBlogs();
}

// Like blog
async function likeBlog(id, currentLikes) {
  await fetch(`${API_BASE}/blogs/${id}`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ likes: currentLikes + 1 })
  });
  loadBlogs();
}

loadBlogs();
